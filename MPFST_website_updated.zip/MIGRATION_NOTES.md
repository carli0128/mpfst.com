
NOTE: after this PR merges go to **Render ▸ Backend ▸ Settings ▸ Start Command** and clear the field so the Docker CMD is used.
