"""
Backend package marker — keeps relative imports simple.
Nothing to configure here.
"""
