import MPFSTWebsite from "@/components/MPFSTWebsite";

export default function Home() {
  return <MPFSTWebsite />;
}

